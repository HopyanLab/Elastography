% manually select roi to help level the curve

function [sx, sy, index]=manual_select_curve_datasize(x, y)

h = figure(500);
clf
plot(x, y, 'k.-')
grid on
h.Position(3:4) = [1000 700];
movegui('center');
[a, b]=ginput(2);
% a=round(a);

ind = x > a(1) & x < a(2);
sx = x(ind);
sy = y(ind);
inds = find(ind == 1);
index = [inds(1) inds(end)];
close(h)
end