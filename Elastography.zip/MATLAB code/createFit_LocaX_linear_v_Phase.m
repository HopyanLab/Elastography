function [f, gof] = createFit_LocaX_linear_v_Phase(X, Y)

%% Fit: 'Displacement pattern along Y at location X v. Phase (linear fit only)'
[xData, yData] = prepareCurveData(X, Y);

eqa = sprintf('a1*abs(x + a2) + a3');

% Set up fittype and options
ft = fittype(eqa, 'independent', 'x', 'dependent', 'y');
opts = fitoptions('Method', 'NonlinearLeastSquares');
opts.Display = 'Off';
opts.StartPoint = [0 0 0];

% Fit model to data
[f, gof] = fit(xData, yData, ft, opts);

% % Plot fit with data
% figure('Name', 'Displacement pattern along Y at location X v. Phase (linear fit only)');
% h = plot(f, xData, yData);