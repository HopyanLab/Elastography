function [f, gof] = createFit_LocaX_v_Phase(X, Y)

%% Fit: 'Displacement pattern along X v. Phase'
[xData, yData] = prepareCurveData(X, Y);

% Set up fittype and options
ft = fittype('sin5');
opts = fitoptions( 'Method', 'NonlinearLeastSquares' );
opts.Display = 'Off';
%opts.Lower = [-Inf 0 -Inf -Inf 0 -Inf];
opts.Normalize = 'off';
%opts.StartPoint = [0.0932276631255787 1.96987484292049 1.66374995110408 0.0157647484918835 0.984937421460244 1.24683215229846 1.24683215229846];

% Fit model to data
[f, gof] = fit(xData, yData, ft, opts);

% % Plot fit with data
% figure('Name', 'Displacement pattern along X v. Phase');
% h = plot(f, xData, yData);
% xlabel('X', 'Interpreter', 'none');
% ylabel('Phase', 'Interpreter', 'none');
% grid on
