function [f, gof] = createFit_LocaY_v_Phase(X, Y)

%% Fit: 'LocaY v. Local phase at Y'
[xData, yData] = prepareCurveData(X, Y);
ft = fittype('poly1');
[f, gof] = fit(xData, yData, ft);

% % Plot fit with data
% figure;
% h = plot(f, xData, yData);
% %set(gca, 'DataAspectRatio', [6 6 1]);
% axis([0 2.6 -0.15 0]);
% set(gcf,'position', [500,500,310,310]);