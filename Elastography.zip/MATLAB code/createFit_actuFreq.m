function [p1, p2, p3, sfit, gof, thres] = createFit_actuFreq(X, Y, InitFreq, InitPhase)

[xData, yData] = prepareCurveData(X, Y);

% Set up fittype and options
ft = fittype( 'sin1' );
opts = fitoptions('Method', 'NonlinearLeastSquares');
opts.Display = 'Off';
opts.Lower = [-Inf 0 -Inf];

% Fit model to data
[sfit, gof] = fit(xData, yData, ft, opts);

p1 = sfit.a1;       % Amplitude
p2 = sfit.b1;       % Frequency
p3 = sfit.c1;       % Phase
thres = gof.rsquare;

% % Plot fit with data
% figure('Name', 'sine fit');
% h = plot(sfit, xData, yData);
% legend(h, 'Y vs. X', 'sine fit', 'Location', 'NorthEast', 'Interpreter', 'none');
% % Label axes
% xlabel('X', 'Interpreter', 'none');
% ylabel('Y', 'Interpreter', 'none');
% grid on
% movegui('north');


