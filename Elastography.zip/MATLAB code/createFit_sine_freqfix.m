function [p1, p2, p3, thres, sfit, gof] = createFit_sine_freqfix(X, Y, InitFreq, InitPhase)

[xData, yData] = prepareCurveData(X, Y);

eqa = sprintf('a1*sin(%d*x + %d + b1) + c1', InitFreq*2*pi, InitPhase);

% Set up fittype and options
ft = fittype(eqa, 'independent', 'x', 'dependent', 'y');
opts = fitoptions('Method', 'NonlinearLeastSquares');
opts.Display = 'Off';
opts.Lower = [0 -pi -15];
opts.Upper = [Inf pi 15];
opts.StartPoint = [15 0 0];

% Fit model to data
[sfit, gof] = fit(xData, yData, ft, opts);

p1 = sfit.a1;           % Amplitude
p2 = sfit.b1;           % Phase
p3 = sfit.c1;           % Position
thres = gof.rsquare;

% % Plot fit with data
% figure('Name', 'sine fit');
% h = plot(sfit, xData, yData);
% legend(h, 'Y vs. X', 'sine fit', 'Location', 'NorthEast', 'Interpreter', 'none');
% % Label axes
% xlabel('X', 'Interpreter', 'none');
% ylabel('Y', 'Interpreter', 'none');
% grid on
% movegui('north');
