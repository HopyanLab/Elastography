%% Import dataset and set up parameters

clear; close all; clc;
[PositionX, PositionY, Time, TrackID, ID] = readvars('filename.csv');

format long;
R_min = 0.99;                 % Minimum R square for saving the fitted result
Fs = 1/0.014979;              % Sampling frequency (i.e., microscope frame rate) in Hz for a FOV of 1000x1000 under 5X;
T = 1/Fs;                     % Sampling period       
L = 1000;                     % Length of signal (for FFT)
t = (0:L-1)*T;                % Time vector (for FFT)
InitFreq = 10;                % Define initial actuation Frequency in Hz
InitPhase = 0;                % Define initial phase for point at (0,0)
tracks = min(TrackID);
trackf = max(TrackID);
x = find(TrackID == tracks);
Tt = Time(x)/Fs;              % Convert frame numbers to seconds

%% Fit actuation requency from glass capillary if necessary

Disp = PositionX(x) - mean(PositionX(x));                   % Horizontal displacement curve
DispY = PositionY(x) - mean(PositionY(x));                  % Vertical displacement curve (for rotational effect)

[sx, sy, index] = manual_select_curve_datasize(Tt, Disp, InitFreq, InitPhase);   % Manual selection of the fit range
sy = sy - (min(sy) + (max(sy) - min(sy))/2);                % Remove DC offset
[p1, p2, p3, gof] = createFit_actuFreq(sx, sy);
InitFreq = p2/2/pi;                                         % Refined actuation frequency in Hz
InitPhase = p3;                                             % Reference starting point for phase

%% Select fit range for all data

clear Disp;
Disp = PositionX(x);
[sx, sy, index] = manual_select_curve_datasize(Tt, Disp);
k = 1;
% SD of the fit by segments to calculate spatial mapping resolution
%{
% N = index(2) - index(1);
% temp = index;
% divs = 8;
% big = N/divs;

% for n = 1:divs
% start = (n - 1)*big + 1 + temp(1);
% finish = n*big + temp(1);
% index = [start, finish];
%}

%% Fit to equation

uniqueTrackID = unique(TrackID);                            % In TrackID, numbers are not consecutive or unique

for j = 1:size(uniqueTrackID)
    i = uniqueTrackID(j);
    x = find(TrackID == i);       
    x_seg = x(index(1):index(2));                           % Segment tracks based on fit range selection
    Disp = PositionX(x_seg) - mean(PositionX(x_seg));
    DispY = PositionY(x_seg) - mean(PositionY(x_seg));
    X_value = mean(PositionX(x_seg));
    Y_value = mean(PositionY(x_seg));
    X_range = max(PositionX(x_seg)) - min(PositionX(x_seg));   
    Tt=Time(x_seg)/Fs;                                             
    [p1, p2, p3, thres, sfit] = createFit_sine_freqfix(Tt, Disp, InitFreq, InitPhase);        % Horizontal sine wave fit, p1(amp), p3(phase)
    [py1, py2, py3, thresy, sfity] = createFit_sine_freqfix(Tt, DispY, InitFreq, InitPhase);  % Vertical sine wave fit
    if thres > R_min                                                   
       Phase_map(k,:)= [(X_value + p3)*0.001, PositionY(x(1))*0.001, p2];                     % X coordinate, Y coordinate, phase,
       flexure(k,:) = [(X_value + p3)*0.001, (Y_value + py3)*0.001, atan((max(DispY) - min(DispY))/(max(Disp) - min(Disp))), p1];   % X coordinate, Y coordinate, angle of rotation, displacement magnitude
       k = k + 1;                
    end 
end
% end

scatter3(flexure(:,1), flexure(:,2), flexure(:,4), '.b');                   % Rotation plot
scatter3(Phase_map(:,1), Phase_map(:,2), Phase_map(:,3), '.b');
[~, index] = min(abs(Phase_map(:,1) - cursor_info.Position(1,1)));            % Manual selection of points to add the origin by linear regression
[~, index1] = min(abs(Phase_map(:,1) - cursor_info1.Position(1,1)));
x_shift = Phase_map(index, 1);
phi_shift = (Phase_map(index,3) - Phase_map(index1,3))*Phase_map(index,2)/(Phase_map(index,2) - Phase_map(index1,2)) + Phase_map(index,3);
Phase_map(:,1) = Phase_map(:,1) - x_shift; 
origin = [0 0 phi_shift 0];
Phase_map = [Phase_map; origin];
Phase_map(:,3) = Phase_map(:,3) - phi_shift;
indexo = size(Phase_map, 1);

%% Find slope along Y

temp = sortrows(Phase_map);
sorted = temp(:,1);

ind = find(sorted >= 0);
ind_Pos = sorted(ind);
N = size(ind_Pos, 1);
idx = 1;
    for n = 1:N-1
        incr = 1;
        while(ind_Pos(n + incr) - ind_Pos(n) <= 500)          
              incr = incr + 1;
              if(n+incr >= N)              
                  break
              end
        end
        incr = incr - 1;
        group = ind_Pos(n:n+incr);
        
        if(size(group) == 1)
            continue
        end
        
        [fitresult, gof] = createFit_LocaY_v_Phase(temp(n:n+incr,2), temp(n:n+incr,3));  
            A_Pos(idx, 1) = fitresult.p1;
            B_Pos(idx, 1) = mean(group);
            idx = idx + 1;
    end

clear ind N idx incr group;
ind = find(sorted <= 0);
ind_Neg = sorted(ind);
N = size(ind_Neg,1);
idx = 1;
    for n = 1:N-1
        incr = 1;
        while(ind_Neg(n + incr) - ind_Neg(n) <= 500)          
              incr = incr + 1;
              if(n+incr >= N)              
                  break
              end
        end
        incr = incr - 1;
        group = ind_Neg(n:n+incr);
        
        if(size(group) == 1)
            continue
        end
        
        [fitresult, gof] = createFit_LocaY_v_Phase(temp(n:n+incr,2), temp(n:n+incr,3));  
            A_Neg(idx, 1) = fitresult.p1;
            B_Neg(idx, 1) = mean(group);
            idx = idx + 1;
    end

A = [A_Pos; A_Neg];
B = [B_Pos; B_Neg];
slope = mean(A);

%% Compensate slope along Y to fit for trend along X

mod_Phase_y = Phase_map(:,3) - slope.*Phase_map(:,2);

%% X-compensation

% linear fit
[f, gof] = createFit_LocaX_linear_v_Phase(Phase_map(:,1), mod_Phase_y);
mod_Phase_x = Phase_map(:,3) - (f.a1*abs(Phase_map(:,1) + f.a2) + f.a3);

% sum of sine fit
% [f, gof] = createFit_LocaX_v_Phase(Phase_map(:,1), mod_Phase_x);  
% mod_Phase_x = mod_Phase_x - f.a1*sin(f.b1*Phase_map(:,1) + f.c1) - f.a2*sin(f.b2*Phase_map(:,1) + f.c2) - f.a3*sin(f.b3*Phase_map(:,1) + f.c3) - f.a4*sin(f.b4*Phase_map(:,1) + f.c4) - f.a5*sin(f.b5*Phase_map(:,1) + f.c5);

ky = mod_Phase_x./Phase_map(:,2);
map = [Phase_map(:,1) Phase_map(:,2) ky];
scatter(Phase_map(:,2), ky);

% Applt filter for ky
for i=1:size(ky,1)
    if map(i,3) < -ky*2 && map(i,3) > 0
        map_filtered(i,:) = [map(i,1) map(i,2) map(i,2)*ky(i)];
    else 
        map_filtered(i,:) = [map(i,1) map(i,2) 0];
    end
    i = i + 1;
end

%% Shear modulus map

[f, gof] = createFit_LocaY_v_Phase(map_filtered(:,2), map_filtered(:,3));
G_avg = 1000*((20*pi*0.001/(-f.p1))^2);
err = map_filtered(:,3) - (f.p1.*map_filtered(:,2) + f.p2);
G = 1000*((20*pi*0.001./(-(f.p1 + err))).^2);    % Calculate the local shear modulus
map_filtered = [map_filtered, G];

figure(3);
dt = delaunayTriangulation(map_filtered(:,1),map_filtered(:,2));
h2 = trisurf(dt.ConnectivityList,map_filtered(:,1),map_filtered(:,2),map_filtered(:,4));
h2.FaceColor = 'interp';
h2.EdgeColor = 'none';
c = colorbar;
c.Label.String = 'Stiffness [Pa]';
grid off;
hold on;
A = scatter(map_filtered(:,1), map_filtered(:,2));
uistack(A, 'top');